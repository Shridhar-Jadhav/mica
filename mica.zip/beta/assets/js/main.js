$(document).ready(function () {
    $(".accordion-collapse").on("shown.bs.collapse", function () {
      $(".accordion-item").removeClass("bor-red"); // Remove from all
      $(this).closest(".accordion-item").addClass("bor-red"); // Add to active one
    });
  
    $(".accordion-collapse").on("hidden.bs.collapse", function () {
      $(this).closest(".accordion-item").removeClass("bor-red"); // Remove if collapsed
    });

    $('#clients').owlCarousel({
      loop:true,
      margin:24,
      nav:false,
      dots: false,
      autoplay: true,
      slideTransition: 'linear',
      autoplayTimeout:3000,
      autoplaySpeed:3000,
      autoplayHoverPause: false,
      responsive:{
          0:{
              items:1.8
          },
          420:{
            items: 3
          },
          600:{
              items:4
          },
          900:{
            items:6
          },
          1200:{
              items:8
          }
      }
    })

    $('#about-banner').owlCarousel({
      loop:true,
      margin:10,
      nav:false,
      mouseDrag: false,
      touchDrag:false,
      pullDrag:false,
      freeDrag:false,
      dots: false,
      autoplay:true,
      autoplayHoverPause:true,
      smartSpeed: 2000,
      autoplayTimeout:3000,
      animateOut: 'fadeOut',
      animateIn: 'flipInX',
      responsive:{
          0:{
              items:1
          }
      }
    })
    $('#about-banner-sec').owlCarousel({
      loop:true,
      margin:10,
      nav:false,
      // mouseDrag: false,
      // touchDrag:false,
      // pullDrag:false,
      // freeDrag:false,
      dots: true,
      autoplay:true,
      autoplayHoverPause:true,
      smartSpeed: 2000,
      autoplayTimeout:3000,
      animateOut: 'fadeOut',
      animateIn: 'flipInX',
      responsive:{
          0:{
              items:1
          }
      }
    })

    $("#program-btn").click(function(){
      $("#program-links").toggle();
      $("#program-btn").toggleClass("show");
      $("#program-links").toggleClass("act");
    });

    $("#research_and_insights_btn").click(function(){
      $("#research_and_insights_links").toggle();
      $("#research_and_insights_btn").toggleClass("show");
      $("#research_and_insights_links").toggleClass("act");
    });

    $("#campus_life_btn").click(function(){
      $("#campus_life_links").toggle();
      $("#campus_life_btn").toggleClass("show");
      $("#campus_life_links").toggleClass("act");
    });

    $("#About_MICA_btn").click(function(){
      $("#About_MICA_links").toggle();
      $("#About_MICA_btn").toggleClass("show");
      $("#About_MICA_links").toggleClass("act");
    });
  });